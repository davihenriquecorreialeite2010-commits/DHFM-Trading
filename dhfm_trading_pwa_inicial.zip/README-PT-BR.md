# DHFM Trading — pacote inicial PWA

Este pacote transforma o protótipo em uma estrutura básica de PWA instalável.

## O que está incluído
- `index.html`: interface de demonstração.
- `manifest.webmanifest`: nome, ícone e comportamento de instalação.
- `service-worker.js`: cache básico dos arquivos da interface.
- `icons/`: ícones 192x192 e 512x512.

## Limitações importantes
Este pacote ainda NÃO é um sistema de produção:
- Os clientes e campanhas são apenas dados de demonstração mantidos em memória.
- Não existe backend, login real, banco de dados compartilhado ou sincronização entre aparelhos.
- O chat não envia mensagens reais.
- O WhatsApp Business e o Instagram não estão conectados.
- O cache offline guarda a interface, não cria uma base de dados segura nem sincroniza alterações.

Não cadastre dados reais de clientes até implementar autenticação, backend, banco de dados, regras de acesso, backups e controles de privacidade.

## Como publicar para testar a instalação
1. Crie um repositório privado no GitHub (não coloque tokens, senhas ou dados reais de clientes no código).
2. Envie os arquivos e pastas deste pacote para o repositório.
3. Para um teste de interface, ative GitHub Pages nas configurações do repositório. O site deve ser servido por HTTPS para que a instalação PWA funcione.
4. Abra a URL publicada no Chrome/Edge e use a opção de instalar/adicionar à tela inicial, se oferecida pelo dispositivo.
5. Lembre-se: GitHub Pages hospeda arquivos estáticos; não fornece por si só backend seguro, banco de dados ou envio de WhatsApp.

## Arquitetura recomendada para a versão real
- Frontend PWA: hospedagem HTTPS com implantação ligada ao GitHub.
- Backend: endpoints do servidor para operações protegidas e integração de mensagens.
- Banco de dados: PostgreSQL gerenciado com autenticação e regras de acesso por cliente/empresa.
- Autenticação: contas individuais, MFA para administradores e permissões mínimas.
- WhatsApp: WhatsApp Business Platform oficial, credenciais apenas no servidor, webhooks verificados, consentimento e descadastro.
- Segurança: rate limiting, validação no servidor, logs de auditoria, backups, monitoramento e testes de acesso.

## Próxima etapa técnica
Primeiro criar autenticação e banco de dados compartilhado. Depois migrar os formulários de clientes/campanhas para o backend. Só então integrar WhatsApp e relatórios reais.
